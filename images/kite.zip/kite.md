# 登壇者名

Kite

# セッションタイトル

Sass を使ってるなら Bourbon/Neat を使え！
- 超軽量 Sass ライブラリ Bourbon/Neat のススメ -

# 登壇者プロフィール掲載リンク

- Facebook: https://www.facebook.com/kite.koga
- Twitter: https://twitter.com/ixkaito
- GitHub: https://github.com/ixkaito
- Website: http://kiteretz.com/

# セッション概要

BootStrap などの CSS フレームワークが抱える根本的な問題を解決してくれる Bourbon/Neat という超軽量 Sass ライブラリをご紹介します。Bourbon ツールセット (Bourbon/Neat/Bitter/Refills) の説明や使うメリットをお話し、それらを使ったライブコーディングを行う予定です。

# セッション時間

45分

# chat with a speakers プログラム**の可否

可

# セッションWeb配信***の可否

可

# セッションタグ

HTML, CSS, JS, UI・UX, デザイナ向け, エンジニア向け, 開発
